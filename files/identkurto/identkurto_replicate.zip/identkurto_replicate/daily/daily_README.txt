Data List: daily
Data Updated: 2023-09-29

FRED (Federal Reserve Economic Data)
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
Economic Research Division
Federal Reserve Bank of St. Louis

Series ID                                                             
----------------------------------------------------------------------
BAMLC0A2CAA                                                           

Title
----------------------------------------------------------------------
ICE BofA AA US Corporate Index Option-Adjusted Spread                 

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This data represents the Option-Adjusted Spread (OAS) of the ICE BofA 
AA US Corporate Index, a subset of the ICE BofA US Corporate Master   
Index tracking the performance of US dollar denominated investment    
grade rated corporate debt publicly issued in the US domestic market. 
This subset includes all securities with a given investment grade     
rating AA.                                                            
The ICE BofA OAS are the calculated spreads between a computed OAS    
index of all bonds in a given rating category and a spot Treasury     
curve. An OAS index is constructed using each constituent bond's OAS, 
weighted by market capitalization. When the last calendar day of the  
month takes place on the weekend, weekend observations will occur as a
result of month ending accrued interest adjustments.                  
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
BAMLC0A2CAAEY                                                         

Title
----------------------------------------------------------------------
ICE BofA AA US Corporate Index Effective Yield                        

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This data represents the effective yield of the ICE BofA AA US        
Corporate Index, a subset of the ICE BofA US Corporate Master Index   
tracking the performance of US dollar denominated investment grade    
rated corporate debt publicly issued in the US domestic market. This  
subset includes all securities with a given investment grade rating   
AA. When the last calendar day of the month takes place on the        
weekend, weekend observations will occur as a result of month ending  
accrued interest adjustments.                                         
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
BAMLC0A4CBBB                                                          

Title
----------------------------------------------------------------------
ICE BofA BBB US Corporate Index Option-Adjusted Spread                

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This data represents the Option-Adjusted Spread (OAS) of the ICE BofA 
BBB US Corporate Index, a subset of the ICE BofA US Corporate Master  
Index tracking the performance of US dollar denominated investment    
grade rated corporate debt publicly issued in the US domestic market. 
This subset includes all securities with a given investment grade     
rating BBB.                                                           
The ICE BofA OASs are the calculated spreads between a computed OAS   
index of all bonds in a given rating category and a spot Treasury     
curve. An OAS index is constructed using each constituent bond's OAS, 
weighted by market capitalization. When the last calendar day of the  
month takes place on the weekend, weekend observations will occur as a
result of month ending accrued interest adjustments.                  
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
BAMLC0A4CBBBEY                                                        

Title
----------------------------------------------------------------------
ICE BofA BBB US Corporate Index Effective Yield                       

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This data represents the effective yield of the ICE BofA BBB US       
Corporate Index, a subset of the ICE BofA US Corporate Master Index   
tracking the performance of US dollar denominated investment grade    
rated corporate debt publicly issued in the US domestic market. This  
subset includes all securities with a given investment grade rating   
BBB. When the last calendar day of the month takes place on the       
weekend, weekend observations will occur as a result of month ending  
accrued interest adjustments.                                         
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
BAMLEMCBPIOAS                                                         

Title
----------------------------------------------------------------------
ICE BofA Emerging Markets Corporate Plus Index Option-Adjusted Spread 

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This data represents the Option-Adjusted Spread (OAS) for the ICE BofA
Emerging Markets Corporate Plus Index                                 
(https://fred.stlouisfed.org/series/BAMLEMCBPITRIV?cid=32413), which  
tracks the performance of US dollar (USD) and Euro denominated        
emerging markets non-sovereign debt publicly issued within the major  
domestic and Eurobond markets. To qualify for inclusion in the index, 
the issuer of debt must have risk exposure to countries other than    
members of the FX G10 (US, Japan, New Zealand, Australia, Canada,     
Sweden, UK, Switzerland, Norway, and Euro Currency Members), all      
Western European countries, and territories of the US and Western     
European countries. Each security must also be denominated in USD or  
Euro with a time to maturity greater than 1 year and have a fixed     
coupon. For inclusion in the index, investment grade rated bonds of   
qualifying issuers must have at least 250 million (Euro or USD) in    
outstanding face value, and below investment grade rated bonds must   
have at least 100 million (Euro or USD) in outstanding face value. The
index includes corporate and quasi-government debt of qualifying      
countries, but excludes sovereign and supranational debt. Other types 
of securities acceptable for inclusion in this index are: original    
issue zero coupon bonds, "global" securities (debt issued in the US   
domestic bond markets as well the Eurobond Market simultaneously),    
144a securities, pay-in-kind securities (includes toggle notes),      
callable perpetual securities (qualify if they are at least one year  
from the first call date), fixed-to-floating rate securities (qualify 
if the securities are callable within the fixed rate period and are at
least one year from the last call prior to the date the bond          
transitions from a fixed to a floating rate security). Defaulted      
securities are excluded from the Index.                               
ICE BofA Explains the Construction Methodology of this series as:     
Index constituents are capitalization-weighted based on their current 
amount outstanding. With the exception of US mortgage pass-throughs   
and US structured products (ABS, CMBS and CMOs), accrued interest is  
calculated assuming next-day settlement. Accrued interest for US      
mortgage pass-through and US structured products is calculated        
assuming same-day settlement. Cash flows from bond payments that are  
received during the month are retained in the index until             
the end of the month and then are removed as part of the rebalancing. 
Cash does not earn any reinvestment income while it is held in the    
Index. The Index is rebalanced on the last calendar day of the month, 
based on information available up to and including the third business 
day before the last business day of the month. Issues that meet the   
qualifying criteria are included in the Index for the following month.
Issues that no longer meet the criteria during the course of the month
remain in the Index until the next month-end rebalancing at which     
point they are removed from the Index.                                
                                                                      
The ICE BofA OASs are the calculated spreads between a computed OAS   
index of all bonds in a given rating category and a spot Treasury     
curve. An OAS index is constructed using each constituent bond's OAS, 
weighted by market capitalization. When the last calendar day of the  
month takes place on the weekend, weekend observations will occur as a
result of month ending accrued interest adjustments. When the last    
calendar day of the month takes place on the weekend, weekend         
observations will occur as a result of month ending accrued interest  
adjustments.                                                          
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
BAMLH0A0HYM2                                                          

Title
----------------------------------------------------------------------
ICE BofA US High Yield Index Option-Adjusted Spread                   

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The ICE BofA Option-Adjusted Spreads (OASs) are the calculated spreads
between a computed OAS index of all bonds in a given rating category  
and a spot Treasury curve. An OAS index is constructed using each     
constituent bond's OAS, weighted by market capitalization. The ICE    
BofA High Yield Master II OAS uses an index of bonds that are below   
investment grade (those rated BB or below).                           
This data represents the ICE BofA US High Yield Index value, which    
tracks the performance of US dollar denominated below investment grade
rated corporate debt publicly issued in the US domestic market. To    
qualify for inclusion in the index, securities must have a below      
investment grade rating (based on an average of Moody's, S&P, and     
Fitch) and an investment grade rated country of risk (based on an     
average of Moody's, S&P, and Fitch foreign currency long term         
sovereign debt ratings). Each security must have greater than 1 year  
of remaining maturity, a fixed coupon schedule, and a minimum amount  
outstanding of $100 million. Original issue zero coupon bonds,        
"global" securities (debt issued simultaneously in the eurobond and US
domestic bond markets), 144a securities and pay-in-kind securities,   
including toggle notes, qualify for inclusion in the Index. Callable  
perpetual securities qualify provided they are at least one year from 
the first call date. Fixed-to-floating rate securities also qualify   
provided they are callable within the fixed rate period and are at    
least one year from the last call prior to the date the bond          
transitions from a fixed to a floating rate security. DRD-eligible and
defaulted securities are excluded from the Index.                     
                                                                      
ICE BofA Explains the Construction Methodology of this series as:     
Index constituents are capitalization-weighted based on their current 
amount outstanding. With the exception of U.S. mortgage pass-throughs 
and U.S. structured products (ABS, CMBS and CMOs), accrued interest is
calculated assuming next-day settlement. Accrued interest for U.S.    
mortgage pass-through and U.S. structured products is calculated      
assuming same-day settlement. Cash flows from bond payments that are  
received during the month are retained in the index until the end of  
the month and then are removed as part of the rebalancing. Cash does  
not earn any reinvestment income while it is held in the Index. The   
Index is rebalanced on the last calendar day of the month, based on   
information available up to and including the third business day      
before the last business day of the month. Issues that meet the       
qualifying criteria are included in the Index for the following month.
Issues that no longer meet the criteria during the course of the month
remain in the Index until the next month-end rebalancing at which     
point they are removed from the Index.                                
                                                                      
When the last calendar day of the month takes place on the weekend,   
weekend observations will occur as a result of month ending accrued   
interest adjustments.                                                 
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
BAMLHE00EHYIOAS                                                       

Title
----------------------------------------------------------------------
ICE BofA Euro High Yield Index Option-Adjusted Spread                 

Source
----------------------------------------------------------------------
Ice Data Indices, LLC                                                 

Release
----------------------------------------------------------------------
ICE BofA Indices                                                      

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This data represents the Option-Adjusted Spread (OAS) of the ICE BofA 
Euro High Yield Index tracks the performance of Euro denominated below
investment grade corporate debt publicly issued in the euro domestic  
or eurobond markets. Qualifying securities must have a below          
investment grade rating (based on an average of Moody's, S&P, and     
Fitch). Qualifying securities must have at least one year remaining   
term to maturity, a fixed coupon schedule, and a minimum amount       
outstanding of Euro 100 million. Original issue zero coupon bonds,    
"global" securities (debt issued simultaneously in the eurobond and   
euro domestic markets), 144a securities and pay-in-kind securities,   
including toggle notes, qualify for inclusion in the Index. Callable  
perpetual securities qualify provided they are at least one year from 
the first call date. Fixed-to-floating rate securities also qualify   
provided they are callable within the fixed rate period and are at    
least one year from the last call prior to the date the bond          
transitions from a fixed to a floating rate security. Defaulted,      
warrant-bearing and euro legacy currency securities are excluded from 
the Index.                                                            
                                                                      
ICE BofA Explains the Construction Methodology of this series as:     
Index constituents are capitalization-weighted based on their current 
amount outstanding. With the exception of U.S. mortgage pass-throughs 
and U.S. structured products (ABS, CMBS and CMOs), accrued interest is
calculated assuming next-day settlement. Accrued interest for U.S.    
mortgage pass-through and U.S. structured products is calculated      
assuming same-day settlement. Cash flows from bond payments that are  
received during the month are retained in the index until             
the end of the month and then are removed as part of the rebalancing. 
Cash does not earn any reinvestment income while it is held in the    
Index. The Index is rebalanced on the last calendar day of the month, 
based on information available up to and including the third business 
day before the last business day of the month. Issues that meet the   
qualifying criteria are included in the Index for the following month.
Issues that no longer meet the criteria during the course of the month
remain in the Index until the next month-end rebalancing at which     
point they are removed from the Index.                                
                                                                      
The ICE BofA OASs are the calculated spreads between a computed OAS   
index of all bonds in a given rating category and a spot Treasury     
curve. An OAS index is constructed using each constituent bond's OAS, 
weighted by market capitalization. When the last calendar day of the  
month takes place on the weekend, weekend observations will occur as a
result of month ending accrued interest adjustments.                  
                                                                      
The index data referenced herein is the property of ICE Data Indices, 
LLC, its affiliates, ("ICE") and/or its Third Party Suppliers and has 
been licensed for use by the Federal Reserve Bank of St. Louis. ICE,  
its affiliates and Third Party Suppliers accept no liability in       
connection with its use.                                              
                                                                      
Copyright, 2017, ICE Benchmark Administration. Reprinted with         
permission.                                                           



Series ID                                                             
----------------------------------------------------------------------
DCOILBRENTEU                                                          

Title
----------------------------------------------------------------------
Crude Oil Prices: Brent - Europe                                      

Source
----------------------------------------------------------------------
U.S. Energy Information Administration                                

Release
----------------------------------------------------------------------
Spot Prices                                                           

Units
----------------------------------------------------------------------
Dollars per Barrel                                                    

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Definitions, Sources and Explanatory Notes                            
(http://www.eia.doe.gov/dnav/pet/TblDefs/pet_pri_spt_tbldef2.asp)     



Series ID                                                             
----------------------------------------------------------------------
DCOILWTICO                                                            

Title
----------------------------------------------------------------------
Crude Oil Prices: West Texas Intermediate (WTI) - Cushing, Oklahoma   

Source
----------------------------------------------------------------------
U.S. Energy Information Administration                                

Release
----------------------------------------------------------------------
Spot Prices                                                           

Units
----------------------------------------------------------------------
Dollars per Barrel                                                    

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Definitions, Sources and Explanatory Notes                            
(http://www.eia.doe.gov/dnav/pet/TblDefs/pet_pri_spt_tbldef2.asp)     



Series ID                                                             
----------------------------------------------------------------------
DFEDTAR                                                               

Title
----------------------------------------------------------------------
Federal Funds Target Rate (DISCONTINUED)                              

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
FOMC Press Release                                                    

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, 7-Day                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Data for the period prior to 1994 come from the working paper "A New  
Federal Funds Rate Target Series: September 27, 1982 - December 31,   
1993" (Thornton, Federal Reserve Bank of St. Louis, 2005,             
http://research.stlouisfed.org/wp/2005/2005-032.pdf). Due to an error 
in the paper values from April 2, 1986 - April 20, 1986 were adjusted 
manually to 7.3125%. Data from 1994 to the present are derived from   
FOMC meeting transcripts and FOMC meeting statements,                 
http://www.federalreserve.gov/fomc/.                                  
                                                                      
Effective December 16, 2008, target rate is reported as a range.      
Current data at https://fred.stlouisfed.org/series/DFEDTARU and       
https://fred.stlouisfed.org/series/DFEDTARL                           



Series ID                                                             
----------------------------------------------------------------------
DFEDTARL                                                              

Title
----------------------------------------------------------------------
Federal Funds Target Range - Lower Limit                              

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
FOMC Press Release                                                    

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, 7-Day                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This series represents lower limit of the federal funds target range  
established by the Federal Open Market Committee. The data updated    
each day is the data effective as of that day.                        



Series ID                                                             
----------------------------------------------------------------------
DFEDTARU                                                              

Title
----------------------------------------------------------------------
Federal Funds Target Range - Upper Limit                              

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
FOMC Press Release                                                    

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, 7-Day                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
This series represents upper limit of the federal funds target range  
established by the Federal Open Market Committee. The data updated    
each day is the data effective as of that day.                        



Series ID                                                             
----------------------------------------------------------------------
DFF                                                                   

Title
----------------------------------------------------------------------
Federal Funds Effective Rate                                          

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily, 7-Day                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For additional historical federal funds rate data, please see  Daily  
Federal Funds Rate from 1928-1954                                     
(https://fred.stlouisfed.org/categories/33951).                       
                                                                      
The federal funds rate is the interest rate at which depository       
institutions trade federal funds (balances held at Federal Reserve    
Banks) with each other overnight. When a depository institution has   
surplus balances in its reserve account, it lends to other banks in   
need of larger balances. In simpler terms, a bank with excess cash,   
which is often referred to as liquidity, will lend to another bank    
that needs to quickly raise liquidity. (1) The rate that the borrowing
institution pays to the lending institution is determined between the 
two banks; the weighted average rate for all of these types of        
negotiations is called the effective federal funds rate.(2) The       
effective federal funds rate is essentially determined by the market  
but is influenced by the Federal Reserve through open market          
operations to reach the federal funds rate target.(2)                 
                                                                      
The Federal Open Market Committee (FOMC) meets eight times a year to  
determine the federal funds target rate. As previously stated, this   
rate influences the effective federal funds rate through open market  
operations or by buying and selling of government bonds (government   
debt).(2) More specifically, the Federal Reserve decreases liquidity  
by selling government bonds, thereby raising the federal funds rate   
because banks have less liquidity to trade with other banks.          
Similarly, the Federal Reserve can increase liquidity by buying       
government bonds, decreasing the federal funds rate because banks have
excess liquidity for trade. Whether the Federal Reserve wants to buy  
or sell bonds depends on the state of the economy. If the FOMC        
believes the economy is growing too fast and inflation pressures are  
inconsistent with the dual mandate of the Federal Reserve, the        
Committee may set a higher federal funds rate target to temper        
economic activity. In the opposing scenario, the FOMC may set a lower 
federal funds rate target to spur greater economic activity.          
Therefore, the FOMC must observe the current state of the economy to  
determine the best course of monetary policy that will maximize       
economic growth while adhering to the dual mandate set forth by       
Congress. In making its monetary policy decisions, the FOMC considers 
a wealth of economic data, such as: trends in prices and wages,       
employment, consumer spending and income, business investments, and   
foreign exchange markets.                                             
                                                                      
The federal funds rate is the central interest rate in the U.S.       
financial market. It influences other interest rates such as the prime
rate, which is the rate banks charge their customers with higher      
credit ratings. Additionally, the federal funds rate indirectly       
influences longer- term interest rates such as mortgages, loans, and  
savings, all of which are very important to consumer wealth and       
confidence.(2)                                                        
                                                                      
References                                                            
(1) Federal Reserve Bank of New York. "Federal funds." Fedpoints,     
August 2007.                                                          
(2) Monetary Policy                                                   
(https://www.federalreserve.gov/monetarypolicy.htm), Board of         
Governors of the Federal Reserve System.                              



Series ID                                                             
----------------------------------------------------------------------
DFII10                                                                

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,
Quoted on an Investment Basis, Inflation-Indexed                      

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DFII5                                                                 

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 5-Year Constant Maturity, 
Quoted on an Investment Basis, Inflation-Indexed                      

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DFII7                                                                 

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity, 
Quoted on an Investment Basis, Inflation-Indexed                      

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS1                                                                  

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 1-Year Constant Maturity, 
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS10                                                                 

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release                          
(https://www.federalreserve.gov/releases/h15/current/h15.pdf) notes   
and Treasury Yield Curve Methodology                                  
(https://www.treasury.gov/resource-center/data-chart-center/interest-r



Series ID                                                             
----------------------------------------------------------------------
DGS1MO                                                                

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 1-Month Constant Maturity,
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS2                                                                  

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 2-Year Constant Maturity, 
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS3                                                                  

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 3-Year Constant Maturity, 
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS3MO                                                                

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 3-Month Constant Maturity,
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS5                                                                  

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 5-Year Constant Maturity, 
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS6MO                                                                

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 6-Month Constant Maturity,
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DGS7                                                                  

Title
----------------------------------------------------------------------
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity, 
Quoted on an Investment Basis                                         

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
For further information regarding treasury constant maturity data,    
please refer to the H.15 Statistical Release notes                    
(https://www.federalreserve.gov/releases/h15/default.htm) and the     
Treasury Yield Curve Methodology                                      
(https://home.treasury.gov/policy-issues/financing-the-government/inte



Series ID                                                             
----------------------------------------------------------------------
DTWEXEMEGS                                                            

Title
----------------------------------------------------------------------
Nominal Emerging Market Economies U.S. Dollar Index                   

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.10 Foreign Exchange Rates                                           

Units
----------------------------------------------------------------------
Index Jan 2006=100                                                    

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
NASDAQCOM                                                             

Title
----------------------------------------------------------------------
NASDAQ Composite Index                                                

Source
----------------------------------------------------------------------
NASDAQ OMX Group                                                      

Release
----------------------------------------------------------------------
NASDAQ                                                                

Units
----------------------------------------------------------------------
Index Feb 5, 1971=100                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The observations for the NASDAQ Composite Index represent the daily   
index value at market close. The market typically closes at 4 PM ET,  
except for holidays when it sometimes closes early.                   
                                                                      
The NASDAQ Composite Index is a market capitalization weighted index  
with more than 3000 common equities listed on the NASDAQ Stock Market.
The types of securities in the index include American depositary      
receipts (ADRs), common stocks, real estate investment trusts (REITs),
and tracking stocks. The index includes all NASDAQ listed stocks that 
are not derivatives, preferred shares, funds, exchange-traded funds   
(ETFs) or debentures.                                                 
                                                                      
Copyright Â© 2016, NASDAQ OMX Group, Inc.                           



Series ID                                                             
----------------------------------------------------------------------
NFCI                                                                  

Title
----------------------------------------------------------------------
Chicago Fed National Financial Conditions Index                       

Source
----------------------------------------------------------------------
Federal Reserve Bank of Chicago                                       

Release
----------------------------------------------------------------------
Chicago Fed National Financial Conditions Index                       

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Weekly, Ending Friday                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The Chicago Fed's National Financial Conditions Index (NFCI) provides 
a comprehensive weekly update on U.S. financial conditions in money   
markets, debt and equity markets and the traditional and "shadow"     
banking systems. Positive values of the NFCI indicate financial       
conditions that are tighter than average, while negative values       
indicate financial conditions that are looser than average.           
                                                                      
For further information, please visit the Federal Reserve Bank of     
Chicago                                                               
(http://www.chicagofed.org/webpages/publications/nfci/index.cfm).     



Series ID                                                             
----------------------------------------------------------------------
T5YIE                                                                 

Title
----------------------------------------------------------------------
5-Year Breakeven Inflation Rate                                       

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     

Release
----------------------------------------------------------------------
Interest Rate Spreads                                                 

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Daily                                                                 

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The breakeven inflation rate represents a measure of expected         
inflation derived from 5-Year Treasury Constant Maturity Securities   
(BC_5YEAR) and 5-Year Treasury Inflation-Indexed Constant Maturity    
Securities (TC_5YEAR). The latest value implies what market           
participants expect inflation to be in the next 5 years, on average.  
Starting with the update on June 21, 2019, the Treasury bond data used
in calculating interest rate spreads is obtained directly from the    
U.S. Treasury Department                                              
(https://www.treasury.gov/resource-center/data-chart-center/interest-r



Series ID                                                             
----------------------------------------------------------------------
VIXCLS                                                                

Title
----------------------------------------------------------------------
CBOE Volatility Index: VIX                                            

Source
----------------------------------------------------------------------
Chicago Board Options Exchange                                        

Release
----------------------------------------------------------------------
CBOE Market Statistics                                                

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
VIX measures market expectation of near term volatility conveyed by   
stock index option prices. Copyright, 2016, Chicago Board Options     
Exchange, Inc. Reprinted with permission.                             



Series ID                                                             
----------------------------------------------------------------------
WILL5000IND                                                           

Title
----------------------------------------------------------------------
Wilshire 5000 Total Market Index                                      

Source
----------------------------------------------------------------------
Wilshire Associates                                                   

Release
----------------------------------------------------------------------
Wilshire Indexes                                                      

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The observations for the Wilshire 5000 Total Market Index represent   
the daily index value at market close. The market typically closes at 
4 PM ET, except for holidays when it sometimes closes early.          
                                                                      
The total market indexes are total market returns, which do include   
reinvested dividends. Copyright, 2016, Wilshire Associates            
Incorporated. Reprinted with permission. For more information about   
the various indexes, visit Wilshire Associates                        
(http://www.wilshire.com/Indexes).                                    



Series ID                                                             
----------------------------------------------------------------------
WILL5000INDFC                                                         

Title
----------------------------------------------------------------------
Wilshire 5000 Total Market Full Cap Index (DISCONTINUED)              

Source
----------------------------------------------------------------------
Wilshire Associates                                                   

Release
----------------------------------------------------------------------
Wilshire Indexes                                                      

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The observations for the Wilshire 5000 Total Market Full Cap Index    
represent the daily index value at market close. The market typically 
closes at 4 PM ET, except for holidays when it sometimes closes early.
                                                                      
The total market indexes are total market returns, which do include   
reinvested dividends. The designation Full Cap for an index signifies 
a float adjusted market capitalization that includes shares of stock  
not considered available to "ordinary" investors. Copyright, 2016,    
Wilshire Associates Incorporated. Reprinted with permission. For more 
information about the various indexes, visit Wilshire Associates      
(http://www.wilshire.com/Indexes).                                    



Series ID                                                             
----------------------------------------------------------------------
WILL5000PR                                                            

Title
----------------------------------------------------------------------
Wilshire 5000 Price Index                                             

Source
----------------------------------------------------------------------
Wilshire Associates                                                   

Release
----------------------------------------------------------------------
Wilshire Indexes                                                      

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The observations for the Wilshire 5000 Price Index represent the daily
index value at market close. The market typically closes at 4 PM ET,  
except for holidays when it sometimes closes early.                   
                                                                      
The price indexes are price returns, which do not reinvest dividends. 
Copyright, 2016, Wilshire Associates Incorporated. Reprinted with     
permission. For more information about the various indexes, visit     
Wilshire Associates (http://www.wilshire.com/Indexes).                



Series ID                                                             
----------------------------------------------------------------------
WILLLRGCAP                                                            

Title
----------------------------------------------------------------------
Wilshire US Large-Cap Total Market Index                              

Source
----------------------------------------------------------------------
Wilshire Associates                                                   

Release
----------------------------------------------------------------------
Wilshire Indexes                                                      

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The observations for the Wilshire US Large-Cap Total Market Index     
represent the daily index value at market close. The market typically 
closes at 4 PM ET, except for holidays when it sometimes closes early.
                                                                      
The total market indexes are total market returns, which do include   
reinvested dividends. Copyright, 2016, Wilshire Associates            
Incorporated. Reprinted with permission. For more information about   
the various indexes, visit Wilshire Associates                        
(http://www.wilshire.com/Indexes).                                    



Series ID                                                             
----------------------------------------------------------------------
WILLSMLCAP                                                            

Title
----------------------------------------------------------------------
Wilshire US Small-Cap Total Market Index                              

Source
----------------------------------------------------------------------
Wilshire Associates                                                   

Release
----------------------------------------------------------------------
Wilshire Indexes                                                      

Units
----------------------------------------------------------------------
Index                                                                 

Frequency
----------------------------------------------------------------------
Daily, Close                                                          

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
The observations for the Wilshire US Small-Cap Total Market Index     
represent the daily index value at market close. The market typically 
closes at 4 PM ET, except for holidays when it sometimes closes early.
                                                                      
The total market indexes are total market returns, which do include   
reinvested dividends. Copyright, 2016, Wilshire Associates            
Incorporated. Reprinted with permission. For more information about   
the various indexes, visit Wilshire Associates                        
(http://www.wilshire.com/Indexes).                                    



