% Construct monetary policy and information shocks from central bank surprises.
% Use the median rotation.
clear variables, close all

% Read data
% The data file should contain five columns in this order:
% 1) year, 2) month, 3) day, 4) interest rate surprise, 5) stock price surprise.
% Uncomment one of the filenames below.
data_filename = 'fedsurprises_d.csv';
%data_filename = 'ecbsurprises_me_njt_d.csv';
data_table = readtable(data_filename);
M = data_table{:,4:5};
M_names = data_table.Properties.VariableNames(4:5);

% Construct Poor man's shocks
U_pm = [M(:,1).*(prod(M,2)<0) M(:,1).*(prod(M,2)>=0)];

% Construct shocks by rotation (median rotation)
U_median = signrestr_median(M);

% Save daily shocks
shocks_names = {'MP_pm','CBI_pm', 'MP_median','CBI_median'};
shocks_table = array2table(round([U_pm U_median],8), 'VariableNames', shocks_names);
table_d = [data_table(:,1:3) shocks_table];
filename_d = strrep(['../' data_filename(1:end-6) '_median_d.csv'],'surprises','shocks');
writetable(table_d, filename_d);


% Aggregate and save monthly and quarterly shocks
[table_m, table_q] = table_d2m2q(table_d);
filename_m = strrep(filename_d, '_d.','_m.');
writetable(table_m, filename_m);
filename_q = strrep(filename_d, '_d.','_q.');
writetable(table_q, filename_q);
