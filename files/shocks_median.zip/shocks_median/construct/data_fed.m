% Compute the first principal component of interest rate surprises
% Save this principal component and stock price in a .csv
clear all, close all

% Load the updated Gurkaynak, Sack and Swanson (2005) dataset, 
% courtesy of Refet Gurkaynak.
tab = readtable('../../data/tight_May2019.xls');
tab.date = datetime(tab.Date);
tab = movevars(tab,'date','Before','Date');

% select the sample
isample = tab.date > datetime('01-Jan-1990');
isample(tab.date == datetime('17-Sep-2001')) = 0; % before mkts opened, dropped in Swanson (2020)
isample(tab.date == datetime('25-Nov-2008')) = 0; % before mkts opened, not FOMC announcement, dropped in Swanson (2020)
isample(tab.date == datetime('01-Dec-2008')) = 0; % not FOMC announcement, dropped in Swanson (2020)

tab = tab(isample,:);
fprintf('Data from %s to %s, T=%d\n', tab{1,'date'},tab{end,'date'},size(tab,1))

% compute the principal component
xnames = {'MP1','FF4','ED2','ED3','ED4'};
X = tab{:, xnames};
[coeff,score,latent,tsquared,explained] = pca(normalize(X));
% rescale the 1st principal component
pc1 = score(:,1)/std(score(:,1))*std(tab{:,'ED4'});

% export to csv
year = year(tab.date);
month = month(tab.date);
day = day(tab.date);
pc1ff1_hf = pc1;
sp500_hf = tab.SP500;

tab_out = table(year, month, day, pc1ff1_hf, sp500_hf);
writetable(tab_out, 'fedsurprises_d.csv');