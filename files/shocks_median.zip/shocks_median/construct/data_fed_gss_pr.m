% Compute the first principal component of interest rate surprises
% Save this principal component and stock price in a .csv
clear all, close all

% Load the updated Gurkaynak, Sack and Swanson (2005) dataset, 
% from http://www.bilkent.edu.tr/~refet/GKL_replication.zip
tab = readtable('../../data/GSSrawdata.xlsx');
tab.date = datetime(tab.Date);
tab = movevars(tab,'date','Before','Date');

% select the sample
isample = tab.date > datetime('01-Feb-1990');
isample(tab.date == datetime('17-Sep-2001')) = 0; % joint Fed ECB, before mkts opened, dropped in Swanson (2020)
%isample(tab.date == datetime('25-Nov-2008')) = 0; % before mkts opened, not FOMC announcement, dropped in Swanson (2020)
%isample(tab.date == datetime('01-Dec-2008')) = 0; % not FOMC announcement, dropped in Swanson (2020)
%isample(tab.date == datetime('11-Mar-2008')) = 0; % joint Fed ECB
%isample(tab.date == datetime('08-Oct-2008')) = 0; % joint Fed ECB

tab = tab(isample,:);
fprintf('Data from %s to %s, T=%d\n', tab{1,'date'},tab{end,'date'},size(tab,1))

% compute the principal component
xnames = {'MP1','FF4','ED2','ED3','ED4'};
X = tab{:, xnames};
[coeff,score,latent,tsquared,explained,mu] = pca(normalize(X,'scale','std'), 'Centered', false);
% rescale the 1st principal component
pc1 = score(:,1)/std(score(:,1))*std(tab{:,'ED4'});

% export to csv
year = year(tab.date);
month = month(tab.date);
day = day(tab.date);
pc1ff1_hf = round(pc1, 8);
sp500_hf = round(tab.SP500, 8);

tab_out = table(year, month, day, pc1ff1_hf, sp500_hf);
writetable(tab_out, 'surprises_fed_gss_pr_d.csv');