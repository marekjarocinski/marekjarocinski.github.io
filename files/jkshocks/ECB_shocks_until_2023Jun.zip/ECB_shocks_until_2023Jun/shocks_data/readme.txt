To replicate the computation of the shocks place here the file with ECB surprises - Dataset_EA-MPD.xlsx - downloaded from
https://www.ecb.europa.eu/pub/pdf/annex/Dataset_EA-MPD.xlsx