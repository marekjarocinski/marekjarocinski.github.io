**************************************************************
The ECB shocks are in the files 
shocks_ecb/shocks_ecb_mpd_me_d.csv (daily frequency) and
shocks_ecb/shocks_ecb_mpd_me_m.csv (monthly frequency).
The rest are Matlab programs that construct these shocks, 
provided to answer questions how the shocks are constructed.
**************************************************************

Folder structure:
[functions] - Matlab functions
[shocks_data] - Source data used to construct the shocks
[shocks_ecb] - Updated shocks and the Matlab script that constructs them


Content of [shocks_ecb]:
shocks_ecb_mpd_me_d.csv - ECB shocks, daily frequency
shocks_ecb_mpd_me_m.csv - ECB shocks, monthly frequency
main_ecb.m - Matlab script that constructs the shocks from source data.


Variables in shocks_ecb_mpd_me_d.csv:

date

pc1 - the 1st principal component of the Monetary Event-window changes in overnight index swaps (OIS) with maturities 1-, 3-, 6-months and 1-year (Identifiers: OIS1M, OIS3M, OIS6M, OIS1Y)

STOXX50 - Monetary Event-window changes in the Euro Stoxx 50

MP_pm - Monetary Policy shocks obtained with simple ("Poor Man's") sign restrictions.

CBI_pm - Central Bank Information shocks obtained with simple ("Poor Man's") sign restrictions.

MP_median - Monetary Policy shocks obtained with the median rotation that implements the sign restrictions.

CBI_median - Central Bank Information shocks obtained with the median rotation that implements the sign restrictions.


Variables in shocks_ecb_mpd_me_m.csv:

year, month

pc1_mpd - the 1st principal component of the Monetary Event-window changes in overnight index swaps (OIS) with maturities 1-, 3-, 6-months and 1-year (Identifiers: OIS1M, OIS3M, OIS6M, OIS1Y)

STOXX50_mpd - Monetary Event-window changes in the Euro Stoxx 50

MP_pm_mpd - Monetary Policy shocks obtained with simple ("Poor Man's") sign restrictions.

CBI_pm_mpd - Central Bank Information shocks obtained with simple ("Poor Man's") sign restrictions.

MP_median_mpd - Monetary Policy shocks obtained with the median rotation that implements the sign restrictions.

CBI_median_mpd - Central Bank Information shocks obtained with the median rotation that implements the sign restrictions.

-> These are the variables from shocks_ecb_mpd_me_d.csv aggregated to the monthly frequency by adding up all monetary policy announcements in the month, zero when no monetary policy announcements. The suffix "mpd" (for "Monetary Policy Database") is added to avoid name clashes after merging with other monthly data.


The variables explained:

We decompose the interest rate surprise around monetary policy announcement, pc1,
into a Monetary Policy shock and a Central Bank Information shock. 
For the definition of Monetary Policy and Central Bank Information shocks and the motivation of the sign restrictions that identify them see:
Jarocinski, M. and Karadi, P. (2020) Deconstructing  Monetary Policy Surprises - The Role of Information Shocks, AEJ:Macro, DOI: 10.1257/mac.20180090

The variables satisfy

MP_median + CBI_median = pc1
-> this is the more general decomposition that allows both shocks to be present in each monetary policy announcement

MP_pm + CBI_pm = pc1
-> this is a much more restrictive decomposition assuming that only one of the shocks is present in each monetary policy announcement
